
from tensorflow.keras.applications import ResNet50
from tensorflow.keras.layers import *
from tensorflow.keras.models import Model

def attention_block(x):
    filters=x.shape[-1]
    att=GlobalAveragePooling2D()(x)
    att=Dense(filters//16,activation='relu')(att)
    att=Dense(filters,activation='sigmoid')(att)
    att=Reshape((1,1,filters))(att)
    return Multiply()([x,att])

def build_model():
    backbone=ResNet50(weights='imagenet',include_top=False,input_shape=(224,224,3))

    for layer in backbone.layers:
        layer.trainable=False

    x=backbone.output
    x=attention_block(x)
    x=GlobalAveragePooling2D()(x)
    x=Dense(256,activation='relu')(x)
    x=Dropout(0.5)(x)
    output=Dense(1,activation='sigmoid')(x)

    model=Model(backbone.input,output)
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    return model
