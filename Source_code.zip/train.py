
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.callbacks import EarlyStopping
from models.model import build_model

datagen=ImageDataGenerator(
rescale=1./255,
validation_split=0.15,
rotation_range=20,
zoom_range=0.2,
horizontal_flip=True)

train=datagen.flow_from_directory(
'dataset',
target_size=(224,224),
batch_size=32,
class_mode='binary',
subset='training')

val=datagen.flow_from_directory(
'dataset',
target_size=(224,224),
batch_size=32,
class_mode='binary',
subset='validation')

model=build_model()

stop=EarlyStopping(
monitor='val_loss',
patience=5,
restore_best_weights=True)

history=model.fit(
train,
validation_data=val,
epochs=50,
callbacks=[stop])

model.save('results/model.h5')
