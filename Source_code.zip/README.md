# Automated Breast Cancer Detection Using Attention-Based CNN
Research implementation repository.